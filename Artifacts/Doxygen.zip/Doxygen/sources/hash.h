#include "team.h"

/*! \file hash.h
 *  \brief A file outlining Hash class methods.
 */


/*!
 *  \brief The Hash class defines a hash table structure to store objects
 */
class Hash
{
    //!
    //! \brief BUCKET is an integer used as a max value in calculating hash codes
    //!
    int BUCKET;

    // Pointer to an array
    //!
    //! \brief table is a pointer to a list of QString objects held by this hash table
    //!
    QList<QString> *table;
public:

    Hash();  // Constructor

    // inserts a key into hash table
    //!
    //! \brief insertItem function takes an object and inserts it into the hash table
    //! \param user QString object to be inserted to the hash table
    //! \param x is a key used to find location to store object
    //!
    void insertItem(QString user,int x);

    // hash function to map values to key
    //!
    //! \brief hashFunction is used to hash values given an integer key
    //! \param x integer key divided to find a hash value
    //!
    int hashFunction(int x) {
        return (x % BUCKET);
    }

    //!
    //! \brief foundpass returns whether a given QString value exists in hash table
    //! \param user QString object is the target value to find in the hash table
    //! \return bool value returns true if user is found, false otherwise
    //!
    bool foundpass(QString user);


    //!
    //! \brief findKey function gets a key associated with passed QString object
    //! \param user QString object is the value to find the key for
    //!
    int findkey(QString user);
};
