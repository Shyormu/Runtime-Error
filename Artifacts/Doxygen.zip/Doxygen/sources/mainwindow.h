#ifndef MAINWINDOW_H
#define MAINWINDOW_H

/*! \file mainwindow.h
 *  \brief A file outlining MainWindow class methods.
 */

#include <QMainWindow>
#include "controller.h"
#include "graph.h"

namespace Ui { class MainWindow; }

/*!
 * \brief The MainWindow class defines all primary functionality of the front end display for the project.
 */
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:

    MainWindow(Controller *controller, graph *Graph, QWidget *parent = nullptr);

    ~MainWindow();

    //!
    //! \brief resetDataMembers clears all stored information to a default state.
    //!
    void resetDataMembers();

    //!
    //! \brief refreshWidgets updates the display of all widgets information to the current data.
    //!
    void refreshWidgets();

    //!
    //! \brief sortStadiums sorts the held stadiums to an order
    //!
    void sortStadiums();

    //!
    //! \brief recursiveStadiumSort recursively sorts the stadiums that are currently selected.
    //! \param current QString holds the current stadium.
    //! \param selected vector of QStrings holds all selected stadiums.
    //!
    void recursiveStadiumSort(QString current, QVector<QString> &selected);

    //!
    //! \brief nextStadium gets the weight needed to travel to the next stadium.
    //! \param dist vector of integers holds the distances.
    //! \param selected vector of strings holds all selected stadiums.
    //! \return integer value holding the weight is returned.
    //!
    int nextStadium(QVector<int> dist, QVector<QString> &selected);

private slots:

    //!
    //! \brief on_ClearBtn_clicked clears the screen
    //!
    void on_ClearBtn_clicked();

    //!
    //! \brief on_Loginbtn_clicked attempts to log in with input credentials
    //!
    void on_Loginbtn_clicked();

    //!
    //! \brief keyPressEvent tracks key presses
    //! \param pe holds the key pressed
    //!
    void keyPressEvent(QKeyEvent* pe);

    //!
    //! \brief on_gotodisplaybtn_clicked brings up the screen to take trips
    //!
    void on_gotodisplaybtn_clicked();

    //!
    //! \brief on_teamcombobox_currentTextChanged updates the team combo box to include selected stadiums
    //! \param arg1 QString holds selected stadium
    //!
    void on_teamcombobox_currentTextChanged(const QString &arg1);

    //!
    //! \brief on_displaystadiumteambtn_clicked displays the selected stadium team
    //!
    void on_displaystadiumteambtn_clicked();

    //!
    //! \brief on_disstadiumstadiumbtn_clicked displays the stadiums sorted by stadium
    //!
    void on_disstadiumstadiumbtn_clicked();

    //!
    //! \brief on_disAmericanTeam_clicked displays only American league teams
    //!
    void on_disAmericanTeam_clicked();

    //!
    //! \brief on_disteamopenroof_clicked displays only stadiums with an open roof
    //!
    void on_disteamopenroof_clicked();

    //!
    //! \brief on_disstaddatebtn_clicked displays stadiums by date
    //!
    void on_disstaddatebtn_clicked();

    //!
    //! \brief on_loadTeamInfo_clicked gets all current team information and displays it
    //!
    void on_loadTeamInfo_clicked();

    //!
    //! \brief on_loadSouvenirInfo_clicked gets all current souvenir informtaion and displays it
    //!
    void on_loadSouvenirInfo_clicked();

    //!
    //! \brief on_Backtoadmin_clicked takes user back to the admin page
    //!
    void on_Backtoadmin_clicked();

    //!
    //! \brief on_loadstadiumsbtn_clicked loads all current stadiums for display
    //!
    void on_loadstadiumsbtn_clicked();

    //!
    //! \brief on_backtopass_clicked brings the user back to the initial admin window page
    //!
    void on_backtopass_clicked();

    //!
    //! \brief on_AddSouv_clicked adds currently created souvenir to the souvenirs list for the current team
    //!
    void on_AddSouv_clicked();

    //!
    //! \brief on_BacktoAdmin_clicked returns the user to the admin panel
    //!
    void on_BacktoAdmin_clicked();

    //!
    //! \brief on_TeamCombosouv_activated retrieves all soivenirs for the selected teams in the trip for display
    //! \param arg1 QString holds a stadium name
    //!
    void on_TeamCombosouv_activated(const QString &arg1);

    //!
    //! \brief on_deleteSouvbtn_clicked deletes the currently selected souvenir
    //!
    void on_deleteSouvbtn_clicked();

    //!
    //! \brief on_Souveniralltable_activated keeps track of when the table has a selection made
    //! \param index holds the index of the table
    //!
    void on_Souveniralltable_activated(const QModelIndex &index);

    //!
    //! \brief on_Editsouvbtn_clicked modifies and saves the changes made to the currently selected souvenir
    //!
    void on_Editsouvbtn_clicked();

    //!
    //! \brief on_stadiumcombobox_activated checks for activation to aceept all stadiums for upload
    //! \param arg1
    //!
    void on_stadiumcombobox_activated(const QString &arg1);

    //!
    //! \brief on_editstadium_clicked allows changes to be made for MLB stadiums in database
    //!
    void on_editstadium_clicked();

    //!
    //! \brief on_DFSbtn_clicked performs and displays the results of a DFS traversal on the current graph
    //!
    void on_DFSbtn_clicked();

    //!
    //! \brief on_BFSbtn_clicked performs and displays the results of a BFS traversal on the current graph
    //!
    void on_BFSbtn_clicked();

    //!
    //! \brief on_MSTbtn_clicked finds and displays the MST of the current graph
    //!
    void on_MSTbtn_clicked();

    //!
    //! \brief on_add_button_clicked adds souvenirs to the panel
    //!
    void on_add_button_clicked();

    //!
    //! \brief on_delete_button_clicked deletes souvenirs for the admin panel
    //!
    void on_delete_button_clicked();

    //!
    //! \brief on_calculatesouvbtn_clicked calculates the price of the currently purchased souvenirs
    //!
    void on_calculatesouvbtn_clicked();

    //!
    //! \brief on_clearsouvbtn_clicked clears the souvenir display
    //!
    void on_clearsouvbtn_clicked();

    //!
    //! \brief on_backtotrip_clicked takes user back to the trip planner page
    //!
    void on_backtotrip_clicked();

    //!
    //! \brief on_addtocart_clicked adds the purchase to the running total count
    //!
    void on_addtocart_clicked();

    //!
    //! \brief on_pushButton_clicked selects sorting display for selecting stadiums
    //!
    void on_pushButton_clicked();

    //!
    //! \brief on_pushButton_2_clicked selects unsorted display for selecting stadiums
    //!
    void on_pushButton_2_clicked();

private:
    Ui::MainWindow *ui;
    Controller *m_controller;
    graph *m_graph;

    //!
    //! \brief page integer holds the currently displayed page index
    //!
    int page = 0;

    /*!
     * \brief The tripType emum class holds enumeration values for all available trip types that can be used in the program.
     */
    enum tripType
    {
        Dodgers, /*!< Trip starting from Dodgers is selected. */
        Start,   /*!< Trip start is selected.                 */
        Marlins, /*!< Trip starting from Marlins is selected. */
        Custom,  /*!< Custom trip type is selected.           */
        None     /*!< No trip is selected.                    */
    };

    //!
    //! \brief selectedStadiums vector holds all currently selected stadiums in the trip
    //!
    QVector<QString> selectedStadiums;

    //!
    //! \brief sortedStadiums vector holds all stadiums in the trip, sorted
    //!
    QVector<QString> sortedStadiums;

    //!
    //! \brief totalDistance holds the total distance traveled in the trip
    //!
    double totalDistance = 0;

    //!
    //! \brief trip holds the type of trip currently being taken
    //!
    tripType trip = None;
};
#endif // MAINWINDOW_H
