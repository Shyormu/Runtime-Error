#ifndef GRAPH_H
#define GRAPH_H

/*! \file graph.h
 *  \brief A file outlining graph class methods.
 */

#include <QObject>
#include "controller.h"


/*!
 * \brief The graph class defines a graph data structure with several traversal functions including BFS and DFS. Implements Dijkstra's algorithm.
 */
class graph : public QObject
{
    Q_OBJECT
public:

    graph(QObject *parent = nullptr);

    //!
    //! \brief addEdges function creates edges between vertices in the graph.
    //!
    void addEdges();

    //!
    //! \brief getDistance function returns the value held in graph's distance member variable
    //!
    int getDistance();

    //MST
    //!
    //! \brief primMst finds the MST in the current graph and returns route
    //! \return QVector of QString objects is returned holding the vertices visited
    //!
    QVector<QString> primMst();

    //BFS
    //!
    //! \brief bfsTraversal performs a breadth-first traversal of the current graph and returns route
    //! \param start stadium object represents the starting point of the traversal
    //! \return QVector of QString objects is returned holding the vertices visited
    //!
    QVector<QString> bfsTraversal(stadium start);

    //DFS
    //!
    //! \brief DFS performs a depth-first traversal of the current graph and returns route
    //! \param start stadium object represents thes starting point of the traversal
    //! \return QVector of QString objects is returned holding the vertices visited
    //!
    QVector<QString> DFS(stadium start);

    //Dijkstra's
    //!
    //! \brief dijkstra function uses dijkstra's algorithm to find the shortest path in the graph and returns results
    //! \param start stadium object represents thes starting point of the traversal
    //! \return QVector of integers representing distance
    //!
    QVector<int> dijkstra(stadium start);

    //!
    //! \brief minDistance funciton finds and returns the minimum distance to travel to reach the next stadium
    //! \param dist vector of integers holds all potential distances to add
    //! \param sptSet vector of bool values holds which vertices of the graph are in the shortest path tree
    //! \return integer value holding the minimum distance to travel to reach a stadium is returned
    //!
    int minDistance(QVector<int> dist, QVector<bool> sptSet);

signals:
private:

    //!
    //! \brief distance is an integer variable holding the distance traveled through the graph
    //!
    int distance;

    //!
    //! \brief Control is a controller object
    //!
    Controller control;

    //!
    //! \brief vNum is an integer holding the number of vertices in the graph
    //!
    int vNum;

    //!
    //! \brief maxtrix is a pointer representing a matrix edge structure
    //!
    int** matrix;

    //MST
    //!
    //! \brief minKey finds vertices by minimum key value
    //! \param key vector of integers holds keys for vertices
    //! \param mstSet vector of bool values holds the set of vertices contained in the MST for the graph
    //!
    int minKey(QVector<int> key, QVector<bool> mstSet);

    //!
    //! \brief printMst prints the calculated MST of the graph
    //! \param parent QVector of integers holds the results of finding the MST to print
    //! \return QVector of QString objects is returned holding strings to output as a result
    //!
    QVector<QString> printMst(QVector<int> parent);

    //BFS
    //!
    //! \brief sortStadium sorts a passed stadium object
    //! \param v stadium object holds current stadium to sort
    //! \return QVector of integers is returned
    //!
    QVector<int> sortStadium(stadium v);

    //DFS
    //!
    //! \brief DFSUtil function is a utility function used to perform the DFS algorithm
    //! \param start stadium object holds the stadium to start the DFS from
    //! \param visited array of bool values holds which nodes have already been visited
    //! \param dfsPath vector of strings is used to store the results of the traversal
    //!
    void DFSUtil(stadium start, bool visited[], QVector<QString> &dfsPath);
};

#endif // GRAPH_H
