#ifndef SOUVENIR_H
#define SOUVENIR_H

/*! \file Souvenir.h
 *  \brief A file outlining Souvenir class methods.
 */

#include "admin.h"

/*!
 * \brief The Souvenir class defines an object which holds information about a team's souvenir that can be purchased.
 */
class Souvenir : public QObject
{
    Q_OBJECT
public:

    explicit Souvenir(QObject *parent = nullptr);

    //!
    //! \brief item returns a QString representing the item name of this souvenir.
    //! \return QString holds the item name of the souvenir.
    //!
    QString item() const;

    //!
    //! \brief setItem sets the souvenir item name variable to item.
    //! \param item QString holds the item name to set.
    //!
    void setItem(const QString &item);

    //!
    //! \brief price returns a QString representing the price of this souvenir.
    //! \return QString holds the price of the souvenir.
    //!
    QString price() const;

    //!
    //! \brief setPrice sets the souvenir price variable to price.
    //! \param price QString holds the price to set.
    //!
    void setPrice(QString price);

    //!
    //! \brief team returns a QString representing the name of the team who offers this souvenir.
    //! \return QString holds the team name associated with the souvenir.
    //!
    QString team() const;

    //!
    //! \brief setTeam sets the souvenir team name variable to Team.
    //! \param Team QString holds the team name to set.
    //!
    void setTeam(QString Team);

signals:

public slots:
private:
    //!
    //! \brief m_item is a QString holding the item name.
    //!
    QString m_item;

    //!
    //! \brief m_price is a QString holding the souvenir price.
    //!
    QString m_price;

    //!
    //! \brief TeamName is a QString holding the team name associated with this souvenir.
    //!
    QString TeamName;
};

#endif // SOUVENIR_H
