#ifndef STADIUM_H
#define STADIUM_H

/*! \file stadium.h
 *  \brief A file outlining stadium class methods.
 */

#include "Souvenir.h"

/*!
 * \brief The stadium class defines an object which holds information about a pair of stadiums and their distance from each other.
 */
class stadium : public QObject
{
    Q_OBJECT
public:

    explicit stadium (QObject *parent = nullptr);

    //!
    //! \brief getStadium1 returns a QString representing stadium1 held by this object.
    //! \return QString holds the stadium held as stadium1.
    //!
    QString getStadium1() const;

    //!
    //! \brief setStadium1 sets the stadium1 variable of this object to stadium.
    //! \param stadium QString holds the stadium to save as stadium1.
    //!
    void setStadium1(const QString &stadium);

    //!
    //! \brief getStadium2 returns a QString representing stadium2 held by this object.
    //! \return QString holds the stadium held as stadium2.
    //!
    QString getStadium2() const;

    //!
    //! \brief setStadium2 sets the stadium2 variable of this object to stadium.
    //! \param stadium QString holds the stadium to save as stadium2.
    //!
    void setStadium2(QString stadium);

    //!
    //! \brief getDistance returns a QString representing the distance held by this object.
    //! \return QString holds the distance between stadiums 1 and 2.
    //!
    QString getDistance() const;

    //!
    //! \brief setDistance sets the distance variable of this object to distance.
    //! \param distance QString holds the distance between stadiums.
    //!
    void setDistance(QString distance);

signals:

public slots:
private:
    //!
    //! \brief stadium1 QString holds the first stadium.
    //!
    QString stadium1;

    //!
    //! \brief stadium2 QString holds the second stadium.
    //!
    QString stadium2;

    //!
    //! \brief distance QString holds the distance between stadiums.
    //!
    QString distance;
};
#endif // STADIUM_H
