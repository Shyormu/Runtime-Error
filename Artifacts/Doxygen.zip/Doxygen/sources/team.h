#ifndef TEAM_H
#define TEAM_H

/*! \file team.h
 *  \brief A file outlining Team class methods.
 */

#include "stadium.h"

/*!
 * \brief The Team class defines an object which holds information about an MLB team.
 */
class Team : public QObject
{
    Q_OBJECT
public:

    explicit Team (QObject *parent = nullptr);

    //!
    //! \brief setTeamName function sets the team name variable of this object to name.
    //! \param name QString holds the name to set.
    //!
    void setTeamName(QString name);

    //!
    //! \brief getTeamName function returns the name of this team.
    //! \return QString holds the team's name.
    //!
    QString getTeamName();

    //!
    //! \brief setStadiumName function sets the stadium name variable of this object to stadium.
    //! \param stadium QString holds the name to set.
    //!
    void setStadiumName(QString stadium);

    //!
    //! \brief getStadiumName function returns the name of this team's stadium.
    //! \return QString holds the team's stadium.
    //!
    QString getStadiumName();

    //!
    //! \brief setSeatingCapacity function sets the seating capacity variable of this object to capacity.
    //! \param capacity QString holds the seating capacity to set.
    //!
    void setSeatingCapacity(QString capacity);

    //!
    //! \brief getSeatingCapacity function returns the seating capacity of this team's stadium.
    //! \return QString holds the team's seating capacity.
    //!
    QString getSeatingCapacity();

    //!
    //! \brief setLocation function sets the location variable of this object to location.
    //! \param location QString holds the name of the location to set.
    //!
    void setLocation(QString location);

    //!
    //! \brief getLocation function returns the name of this team's location.
    //! \return QString holds the team's location.
    //!
    QString getLocation();

    //!
    //! \brief setPlayingSurface function sets the playing surface variable of this object to surface.
    //! \param surface QString holds the surface type to set.
    //!
    void setPlayingSurface(QString surface);

    //!
    //! \brief getPlayingSurface function returns the playing surface of this team's stadium.
    //! \return QString holds the team's stadium playing surface.
    //!
    QString getPlayingSurface();

    //!
    //! \brief setLeague function sets the playing league variable of this object to League.
    //! \param League QString holds the league type to set.
    //!
    void setLeague(QString League);

    //!
    //! \brief getLeague function returns the league of this team.
    //! \return QString holds the team's league.
    //!
    QString getLeague();

    //!
    //! \brief setDateOpened function sets the date opened variable of this object to date.
    //! \param date QString holds the date of opening to set.
    //!
    void setDateOpened(QString date);

    //!
    //! \brief getDateOpened function returns the date of opening of this team's stadium.
    //! \return QString holds the team's stadium's date of opening.
    //!
    QString getDateOpened();

    //!
    //! \brief setDTC function sets the distance to center field variable of this object to dtc.
    //! \param dtc QString holds the distance to set.
    //!
    void setDTC(QString dtc);

    //!
    //! \brief getDTC function returns the distance to center field of this team's stadium.
    //! \return QString holds the team's stadium distance to center field.
    //!
    QString getDTC();

    //!
    //! \brief setBallparkTypology function sets the park typology variable of this object to typology.
    //! \param typolgoy QString holds the park typology to set.
    //!
    void setBallparkTypology(QString typology);


    //!
    //! \brief getBallparkTypology function returns the park typology of this team's stadium.
    //! \return QString holds the team's stadium park typology.
    //!
    QString getBallparkTypology();

    //!
    //! \brief setRoofType function sets the roof type variable of this object to rooftype.
    //! \param rooftype QString holds the roof type to set.
    //!
    void setRoofType(QString rooftype);

    //!
    //! \brief getroofType function returns the roof type of this team's stadium.
    //! \return QString holds the team's stadium roof type.
    //!
    QString getroofType();

private:
    //!
    //! \brief teamName is a QString holding the name of the team this object holds.
    //!
    QString teamName;

    //!
    //! \brief stadiumName is a QString holding the name of the stadium this object holds.
    //!
    QString stadiumName;

    //!
    //! \brief seatingCapacity is a QString holding the seating capacity of the stadium this object holds.
    //!
    QString seatingCapacity;

    //!
    //! \brief teamLocation is a QString holding the location of the team this object holds.
    //!
    QString teamLocation;

    //!
    //! \brief playingSurface is a QString holding the type of playing surface of the stadium this object holds.
    //!
    QString playingSurface;

    //!
    //! \brief league is a QString holding the league of the team this object holds.
    //!
    QString league;

    //!
    //! \brief dateOpened is a QString holding the date of opening of the stadium this object holds.
    //!
    QString dateOpened;

    //!
    //! \brief distanceToCenter is a QString holding the distance to center field of the stadium this object holds.
    //!
    QString distanceToCenter;

    //!
    //! \brief ballparkTypology is a QString holding the park typology of the stadium this object holds.
    //!
    QString ballparkTypology;

    //!
    //! \brief teamRoofType is a QString holding the roof type of the stadium this object holds.
    //!
    QString teamRoofType;
};

#endif // TEAM_H
