var searchData=
[
  ['recursivestadiumsort_95',['recursiveStadiumSort',['../class_main_window.html#a267348518dcfcb7583feb8b5cdf43c11',1,'MainWindow']]],
  ['refreshwidgets_96',['refreshWidgets',['../class_main_window.html#adc051838694704d35b75c990bb58ab34',1,'MainWindow']]],
  ['resetdatamembers_97',['resetDataMembers',['../class_main_window.html#aa3a8d97290260b00811e5ede77226103',1,'MainWindow']]]
];
