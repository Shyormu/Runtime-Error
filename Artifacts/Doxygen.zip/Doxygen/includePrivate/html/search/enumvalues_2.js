var searchData=
[
  ['marlins_255',['Marlins',['../class_main_window.html#a3d5565c01445fdfd371dd4d74e15a4d3ad419d5d288bbcc2dd7666d37fa891459',1,'MainWindow']]]
];
