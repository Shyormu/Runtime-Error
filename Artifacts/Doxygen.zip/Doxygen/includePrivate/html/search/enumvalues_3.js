var searchData=
[
  ['none_256',['None',['../class_main_window.html#a3d5565c01445fdfd371dd4d74e15a4d3aac85fca4986713c165d33d8c787672fa',1,'MainWindow']]]
];
