var searchData=
[
  ['start_257',['Start',['../class_main_window.html#a3d5565c01445fdfd371dd4d74e15a4d3a3024b6280bbbb5914ac8c4d559163a96',1,'MainWindow']]]
];
