var searchData=
[
  ['league_36',['league',['../class_team.html#a37843e1cc130ac1df792f0765895e046',1,'Team']]]
];
