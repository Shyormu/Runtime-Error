var searchData=
[
  ['nextstadium_167',['nextStadium',['../class_main_window.html#a283db848befd2a1aa8a8c93e89c7358b',1,'MainWindow']]]
];
