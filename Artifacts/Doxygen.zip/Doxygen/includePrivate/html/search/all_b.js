var searchData=
[
  ['nextstadium_45',['nextStadium',['../class_main_window.html#a283db848befd2a1aa8a8c93e89c7358b',1,'MainWindow']]],
  ['none_46',['None',['../class_main_window.html#a3d5565c01445fdfd371dd4d74e15a4d3aac85fca4986713c165d33d8c787672fa',1,'MainWindow']]]
];
