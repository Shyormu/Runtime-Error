var searchData=
[
  ['triptype_252',['tripType',['../class_main_window.html#a3d5565c01445fdfd371dd4d74e15a4d3',1,'MainWindow']]]
];
