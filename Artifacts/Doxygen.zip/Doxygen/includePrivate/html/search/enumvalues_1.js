var searchData=
[
  ['dodgers_254',['Dodgers',['../class_main_window.html#a3d5565c01445fdfd371dd4d74e15a4d3a479ab76941bef5b71f9feca22965ced3',1,'MainWindow']]]
];
