var searchData=
[
  ['page_236',['page',['../class_main_window.html#aa133ba8ea6390c5d57f5c10edee76ad1',1,'MainWindow']]],
  ['playingsurface_237',['playingSurface',['../class_team.html#a5887e9ddcc86d3c765248ef5853411b7',1,'Team']]]
];
