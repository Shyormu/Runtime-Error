var searchData=
[
  ['control_4',['control',['../classgraph.html#aa17663ec973b1e7d91edad925774061a',1,'graph']]],
  ['custom_5',['Custom',['../class_main_window.html#a3d5565c01445fdfd371dd4d74e15a4d3a5fe561e495e1756cde0d4fce7797e3b9',1,'MainWindow']]]
];
